# EP-01 – Quản trị hệ thống tài khoản nhân viên

## Chạy trên VS Code

Yêu cầu Node.js >= 18.

```powershell
cd account-management-demo
npm start
```

Mở: http://localhost:3000

## 4 tài khoản demo

| Vai trò | Email | Mật khẩu |
|---|---|---|
| Lễ tân | letan@demo.local | LeTan@123 |
| Buồng phòng | buongphong@demo.local | BuongPhong@123 |
| Chủ homestay | chu@demo.local | ChuHomestay@123 |
| Quản trị hệ thống | admin@demo.local | Admin@123 |

## Chức năng theo đề bài

1. Biểu mẫu tạo tài khoản gồm họ tên, email, số điện thoại, vai trò và trạng thái hoạt động.
2. Vai trò được giới hạn đúng 4 giá trị: Lễ tân, Buồng phòng, Chủ homestay, Quản trị hệ thống.
3. Email trùng bị từ chối với thông báo chỉ rõ email đã được sử dụng.
4. Tài khoản mới được sinh mật khẩu tạm và đưa vào Hộp thư mô phỏng; lần đăng nhập đầu tiên bắt buộc đổi mật khẩu.
5. Khi quản trị viên vô hiệu hóa tài khoản, máy chủ chặn phiên đó ngay ở request tiếp theo; giao diện của người dùng kiểm tra mỗi 10 giây, vì vậy thời gian nhận biết không quá 1 phút.

## Kịch bản kiểm thử

- Đăng nhập lần lượt 4 tài khoản mẫu.
- Đăng nhập admin → tạo nhân viên mới.
- Tạo lại cùng email → kiểm tra lỗi email trùng.
- Xem Hộp thư mô phỏng → lấy mật khẩu tạm → đăng nhập tài khoản mới → bị bắt đổi mật khẩu.
- Mở tài khoản nhân viên ở cửa sổ khác → admin vô hiệu hóa → tối đa 10 giây cửa sổ nhân viên bị đăng xuất.

## Reset dữ liệu demo

Nếu muốn tạo lại 4 tài khoản mẫu từ đầu, dừng server rồi xóa:

```text
data/accounts.json
data/mail-outbox.json
```

Sau đó `npm start` lại.
