const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { URL } = require('url');

const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');
const ACCOUNTS_FILE = path.join(DATA_DIR, 'accounts.json');
const MAIL_FILE = path.join(DATA_DIR, 'mail-outbox.json');
const sessions = new Map();
const ROLE_NAMES = ['Lễ tân', 'Buồng phòng', 'Chủ homestay', 'Quản trị hệ thống'];
const SESSION_CHECK_MS = 10_000; // giao diện kiểm tra 10 giây, đáp ứng <= 1 phút

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}
function verifyPassword(password, stored) {
  const [salt, expected] = String(stored).split(':');
  if (!salt || !expected) return false;
  const actual = crypto.scryptSync(password, salt, 64).toString('hex');
  return crypto.timingSafeEqual(Buffer.from(actual, 'hex'), Buffer.from(expected, 'hex'));
}
function randomTempPassword() {
  return crypto.randomBytes(9).toString('base64url') + 'A1!';
}
function nowIso() { return new Date().toISOString(); }
function loadAccounts() {
  if (!fs.existsSync(ACCOUNTS_FILE)) return [];
  try { return JSON.parse(fs.readFileSync(ACCOUNTS_FILE, 'utf8')); } catch { return []; }
}
function saveAccounts(accounts) { fs.writeFileSync(ACCOUNTS_FILE, JSON.stringify(accounts, null, 2)); }
function loadMail() {
  if (!fs.existsSync(MAIL_FILE)) return [];
  try { return JSON.parse(fs.readFileSync(MAIL_FILE, 'utf8')); } catch { return []; }
}
function saveMail(items) { fs.writeFileSync(MAIL_FILE, JSON.stringify(items, null, 2)); }

// Tạo sẵn 4 tài khoản demo để có thể kiểm thử đủ 4 vai trò ngay sau khi npm start.
function seed() {
  const existing = loadAccounts();
  if (existing.length > 0) return;
  const samples = [
    ['Lễ tân Demo', 'letan@demo.local', '0900000001', 'Lễ tân', 'LeTan@123'],
    ['Buồng phòng Demo', 'buongphong@demo.local', '0900000002', 'Buồng phòng', 'BuongPhong@123'],
    ['Chủ homestay Demo', 'chu@demo.local', '0900000003', 'Chủ homestay', 'ChuHomestay@123'],
    ['Quản trị viên Demo', 'admin@demo.local', '0900000000', 'Quản trị hệ thống', 'Admin@123']
  ];
  const now = nowIso();
  const accounts = samples.map(([fullName, email, phone, role, password]) => ({
    id: crypto.randomUUID(), fullName, email, phone, role, active: true,
    passwordHash: hashPassword(password), mustChangePassword: false,
    createdAt: now, updatedAt: now
  }));
  saveAccounts(accounts);
  saveMail([]);
}
seed();

function sendDemoEmail(to, fullName, tempPassword) {
  const mail = loadMail();
  mail.unshift({
    id: crypto.randomUUID(), to,
    subject: 'Tài khoản mới - Mật khẩu tạm thời',
    body: `Xin chào ${fullName},\n\nTài khoản của bạn đã được tạo.\nEmail đăng nhập: ${to}\nMật khẩu tạm thời: ${tempPassword}\n\nBạn bắt buộc phải đổi mật khẩu ở lần đăng nhập đầu tiên.`,
    createdAt: nowIso(), demo: true
  });
  saveMail(mail.slice(0, 100));
}
function parseCookies(req) {
  const result = {};
  const raw = req.headers.cookie || '';
  raw.split(';').forEach(pair => {
    const idx = pair.indexOf('=');
    if (idx < 0) return;
    result[pair.slice(0, idx).trim()] = decodeURIComponent(pair.slice(idx + 1).trim());
  });
  return result;
}
function setCookie(res, name, value, maxAge = 28800) {
  res.setHeader('Set-Cookie', `${name}=${encodeURIComponent(value)}; HttpOnly; Path=/; SameSite=Lax; Max-Age=${maxAge}`);
}
function clearCookie(res, name) { res.setHeader('Set-Cookie', `${name}=; HttpOnly; Path=/; SameSite=Lax; Max-Age=0`); }
function getSession(req) {
  const token = parseCookies(req).sid;
  if (!token) return null;
  const session = sessions.get(token);
  if (!session) return null;
  const account = loadAccounts().find(a => a.id === session.accountId);
  if (!account || !account.active) { sessions.delete(token); return null; }
  return { token, session, account };
}
function requireAuth(req, res, role) {
  const auth = getSession(req);
  if (!auth) { json(res, 401, { error: 'Phiên đăng nhập không hợp lệ hoặc tài khoản đã bị vô hiệu hóa.' }); return null; }
  if (role && auth.account.role !== role) { json(res, 403, { error: 'Bạn không có quyền thực hiện chức năng này.' }); return null; }
  return auth;
}
function json(res, status, body) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(body));
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', chunk => { data += chunk; if (data.length > 1e6) req.destroy(); });
    req.on('end', () => { try { resolve(data ? JSON.parse(data) : {}); } catch { reject(new Error('JSON không hợp lệ')); } });
    req.on('error', reject);
  });
}
function sanitizeAccount(a) {
  return { id: a.id, fullName: a.fullName, email: a.email, phone: a.phone, role: a.role,
    active: a.active, mustChangePassword: a.mustChangePassword, createdAt: a.createdAt, updatedAt: a.updatedAt };
}
function validateAccountInput(body) {
  const fullName = String(body.fullName || '').trim();
  const email = String(body.email || '').trim().toLowerCase();
  const phone = String(body.phone || '').trim();
  const role = String(body.role || '').trim();
  const active = body.active !== false;
  if (!fullName) return 'Họ tên không được để trống.';
  if (!/^\S+@\S+\.\S+$/.test(email)) return 'Email không hợp lệ.';
  if (!/^[0-9+().\-\s]{8,20}$/.test(phone)) return 'Số điện thoại không hợp lệ.';
  if (!ROLE_NAMES.includes(role)) return 'Vai trò không hợp lệ.';
  return { fullName, email, phone, role, active };
}

async function route(req, res) {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const method = req.method;
  const pathname = url.pathname;
  if (pathname.startsWith('/api/')) {
    try {
      if (method === 'POST' && pathname === '/api/login') {
        const body = await readBody(req);
        const email = String(body.email || '').trim().toLowerCase();
        const password = String(body.password || '');
        const account = loadAccounts().find(a => a.email === email);
        if (!account || !verifyPassword(password, account.passwordHash)) return json(res, 401, { error: 'Email hoặc mật khẩu không đúng.' });
        if (!account.active) return json(res, 403, { error: 'Tài khoản đang bị vô hiệu hóa.' });
        const token = crypto.randomBytes(32).toString('hex');
        sessions.set(token, { accountId: account.id, createdAt: Date.now() });
        setCookie(res, 'sid', token);
        return json(res, 200, { account: sanitizeAccount(account), sessionCheckMs: SESSION_CHECK_MS });
      }
      if (method === 'POST' && pathname === '/api/logout') {
        const token = parseCookies(req).sid; if (token) sessions.delete(token); clearCookie(res, 'sid');
        return json(res, 200, { ok: true });
      }
      if (method === 'GET' && pathname === '/api/session') {
        const auth = getSession(req); if (!auth) return json(res, 401, { error: 'SESSION_INVALID' });
        return json(res, 200, { account: sanitizeAccount(auth.account), sessionCheckMs: SESSION_CHECK_MS });
      }
      if (method === 'POST' && pathname === '/api/change-password') {
        const auth = requireAuth(req, res); if (!auth) return;
        const body = await readBody(req);
        const currentPassword = String(body.currentPassword || '');
        const newPassword = String(body.newPassword || '');
        if (!verifyPassword(currentPassword, auth.account.passwordHash)) return json(res, 400, { error: 'Mật khẩu hiện tại không đúng.' });
        if (newPassword.length < 8) return json(res, 400, { error: 'Mật khẩu mới phải có ít nhất 8 ký tự.' });
        if (newPassword === currentPassword) return json(res, 400, { error: 'Mật khẩu mới phải khác mật khẩu hiện tại.' });
        const accounts = loadAccounts(); const a = accounts.find(x => x.id === auth.account.id);
        a.passwordHash = hashPassword(newPassword); a.mustChangePassword = false; a.updatedAt = nowIso(); saveAccounts(accounts);
        return json(res, 200, { ok: true });
      }
      if (pathname === '/api/accounts' && method === 'GET') {
        const auth = requireAuth(req, res, 'Quản trị hệ thống'); if (!auth) return;
        return json(res, 200, { accounts: loadAccounts().map(sanitizeAccount) });
      }
      if (pathname === '/api/accounts' && method === 'POST') {
        const auth = requireAuth(req, res, 'Quản trị hệ thống'); if (!auth) return;
        const data = validateAccountInput(await readBody(req));
        if (typeof data === 'string') return json(res, 400, { error: data });
        const accounts = loadAccounts();
        if (accounts.some(a => a.email === data.email)) return json(res, 409, { error: `Email ${data.email} đã được sử dụng cho một tài khoản khác.` });
        const tempPassword = randomTempPassword();
        const account = { id: crypto.randomUUID(), ...data, passwordHash: hashPassword(tempPassword), mustChangePassword: true, createdAt: nowIso(), updatedAt: nowIso() };
        accounts.push(account); saveAccounts(accounts); sendDemoEmail(account.email, account.fullName, tempPassword);
        return json(res, 201, { account: sanitizeAccount(account), tempPassword, emailSent: true, note: 'Demo: email được lưu trong Hộp thư mô phỏng.' });
      }
      const match = pathname.match(/^\/api\/accounts\/([^/]+)\/status$/);
      if (match && method === 'PATCH') {
        const auth = requireAuth(req, res, 'Quản trị hệ thống'); if (!auth) return;
        const id = match[1]; const body = await readBody(req);
        if (typeof body.active !== 'boolean') return json(res, 400, { error: 'active phải là true/false.' });
        if (id === auth.account.id && body.active === false) return json(res, 400, { error: 'Không thể tự vô hiệu hóa tài khoản quản trị đang đăng nhập.' });
        const accounts = loadAccounts(); const account = accounts.find(a => a.id === id);
        if (!account) return json(res, 404, { error: 'Không tìm thấy tài khoản.' });
        account.active = body.active; account.updatedAt = nowIso(); saveAccounts(accounts);
        return json(res, 200, { account: sanitizeAccount(account), sessionInvalidation: body.active ? null : 'Phiên hiện tại bị vô hiệu hóa ngay ở phía máy chủ; giao diện kiểm tra tối đa 10 giây.' });
      }
      if (pathname === '/api/mail-outbox' && method === 'GET') {
        const auth = requireAuth(req, res, 'Quản trị hệ thống'); if (!auth) return;
        return json(res, 200, { mails: loadMail() });
      }
      return json(res, 404, { error: 'API không tồn tại.' });
    } catch (err) { console.error(err); return json(res, 500, { error: 'Lỗi máy chủ: ' + err.message }); }
  }
  if (method !== 'GET') return json(res, 405, { error: 'Method Not Allowed' });
  let file = pathname === '/' ? '/index.html' : pathname;
  file = path.normalize(file).replace(/^([.][.][\\/])+/, '');
  const filePath = path.join(ROOT, 'public', file);
  if (!filePath.startsWith(path.join(ROOT, 'public'))) return json(res, 403, { error: 'Forbidden' });
  fs.readFile(filePath, (err, data) => {
    if (err) return json(res, 404, { error: 'Không tìm thấy trang.' });
    const ext = path.extname(filePath); const types = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8' };
    res.writeHead(200, { 'Content-Type': types[ext] || 'application/octet-stream' }); res.end(data);
  });
}
http.createServer(route).listen(PORT, () => {
  console.log(`\nEP-01 Account Management Demo: http://localhost:${PORT}`);
  console.log('4 demo accounts:');
  console.log('  Lễ tân          : letan@demo.local / LeTan@123');
  console.log('  Buồng phòng     : buongphong@demo.local / BuongPhong@123');
  console.log('  Chủ homestay    : chu@demo.local / ChuHomestay@123');
  console.log('  Quản trị hệ thống: admin@demo.local / Admin@123');
  console.log('Session check every 10 seconds (<= 1 minute).\n');
});
